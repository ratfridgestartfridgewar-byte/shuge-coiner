# SHUGE COINS

A full-stack website with public signups, a shared leaderboard, persistent individual balances and hourly spin cooldowns, and an admin-only balance editor.

## Features
- Public account registration and login (unique usernames, passwords hashed with bcrypt)
- Shared leaderboard showing each player's SHUGE COINS balance
- One server-validated spin every 60 minutes per account
- Random reward of 10–100 coins per spin
- Individual balances and next-spin timestamps stored in SQLite
- Admin panel to view all accounts and set any balance
- No upgrades, shop, or coin spending

## Run locally
Requires Node.js 20 or newer.

1. Copy `.env.example` to `.env`.
2. Set `ADMIN_PASSWORD` to a long, unique password and `SESSION_SECRET` to a long random secret.
3. Install and start:

   ```bash
   npm install
   npm start
   ```

4. Open `http://localhost:3000`.
5. Sign in with the `ADMIN_USERNAME` and `ADMIN_PASSWORD` you configured. The first account created in a fresh database becomes the admin.

The SQLite database is created at `data/shuge.sqlite`. Back up this folder to preserve player accounts and balances.

## Put it online
Deploy this folder to a Node.js host that supports persistent storage. Configure the environment variables from `.env.example`, set `NODE_ENV=production`, enable HTTPS, and attach a persistent disk/volume for the `data/` directory. Do not deploy on a static-only host: the API and database must run on a server for accounts and the leaderboard to be shared.

For a production deployment with multiple server instances, replace Express's default in-memory session store with a persistent session store (for example, a SQLite- or Redis-backed store). Keep the SQLite database on a single persistent host/volume or migrate it to a managed database before horizontal scaling. Never publish `.env` or the `data/` folder.

## Admin
The initial admin account is created automatically on the first start of an empty database. Its username and password come from `ADMIN_USERNAME` and `ADMIN_PASSWORD`. Keep those secret. Admin status is stored server-side; users cannot grant themselves admin access.

## Rules
- Spins award 10–100 coins.
- A successful spin starts a 60-minute cooldown measured by the server.
- Refreshing or logging out does not reset the cooldown.
- The leaderboard displays the top 100 accounts, ordered by balance.
