const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOUR = 60 * 60 * 1000;
const DATA_DIR = path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });

if (!process.env.SESSION_SECRET || !process.env.ADMIN_PASSWORD) {
  console.error("Set SESSION_SECRET and ADMIN_PASSWORD environment variables. See .env.example.");
  process.exit(1);
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "10kb" }));
app.use(session({
  name: "shuge.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * HOUR
  }
}));

const db = new Database(path.join(DATA_DIR, "shuge.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    coins INTEGER NOT NULL DEFAULT 0 CHECK(coins >= 0),
    next_spin_at INTEGER NOT NULL DEFAULT 0,
    is_admin INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );
`);

const countUsers = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
if (!countUsers) {
  const username = String(process.env.ADMIN_USERNAME || "admin").trim();
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
  db.prepare("INSERT INTO users (username,password_hash,is_admin,created_at) VALUES (?,?,1,?)")
    .run(username, hash, Date.now());
  console.log(`Created initial admin account: ${username}`);
}

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const spinLimiter = rateLimit({ windowMs: 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const usernamePattern = /^[a-zA-Z0-9_]{3,20}$/;

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in first." });
  next();
}
function requireAdmin(req, res, next) {
  const user = db.prepare("SELECT is_admin FROM users WHERE id=?").get(req.session.userId);
  if (!user || !user.is_admin) return res.status(403).json({ error: "Admin access only." });
  next();
}
function publicUser(id) {
  return db.prepare("SELECT id, username, coins, next_spin_at AS nextSpinAt, is_admin AS isAdmin FROM users WHERE id=?").get(id);
}

app.post("/api/register", authLimiter, async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!usernamePattern.test(username)) return res.status(400).json({ error: "Username must be 3–20 characters: letters, numbers, or underscores." });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: "Password must be 8–72 characters." });
  if (db.prepare("SELECT id FROM users WHERE username=? COLLATE NOCASE").get(username)) {
    return res.status(409).json({ error: "That username is already taken." });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (username,password_hash,created_at) VALUES (?,?,?)").run(username, hash, Date.now());
    req.session.userId = Number(result.lastInsertRowid);
    res.json({ user: publicUser(req.session.userId) });
  } catch (e) {
    if (String(e.code).includes("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "That username is already taken." });
    console.error(e); res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE username=? COLLATE NOCASE").get(username);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Incorrect username or password." });
  req.session.userId = user.id;
  res.json({ user: publicUser(user.id) });
});

app.post("/api/logout", requireAuth, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/me", requireAuth, (req, res) => {
  const user = publicUser(req.session.userId);
  if (!user) return res.status(401).json({ error: "Account not found." });
  res.json({ user });
});
app.get("/api/leaderboard", (req, res) => {
  const users = db.prepare("SELECT username, coins FROM users ORDER BY coins DESC, username COLLATE NOCASE ASC LIMIT 100").all();
  res.json({ users });
});

app.post("/api/spin", requireAuth, spinLimiter, (req, res) => {
  const now = Date.now();
  const user = db.prepare("SELECT id, coins, next_spin_at FROM users WHERE id=?").get(req.session.userId);
  if (!user) return res.status(401).json({ error: "Account not found." });
  if (user.next_spin_at > now) return res.status(429).json({ error: "Your next spin is not ready yet.", nextSpinAt: user.next_spin_at });
  const reward = Math.floor(Math.random() * 91) + 10; // 10–100 coins
  const update = db.prepare("UPDATE users SET coins=coins+?, next_spin_at=? WHERE id=? AND next_spin_at<=?")
    .run(reward, now + HOUR, user.id, now);
  if (!update.changes) return res.status(429).json({ error: "Your next spin is not ready yet." });
  res.json({ reward, user: publicUser(user.id) });
});

app.get("/api/admin/users", requireAuth, requireAdmin, (req, res) => {
  const users = db.prepare("SELECT id, username, coins, next_spin_at AS nextSpinAt, is_admin AS isAdmin, created_at AS createdAt FROM users ORDER BY username COLLATE NOCASE").all();
  res.json({ users });
});
app.patch("/api/admin/users/:id/coins", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const coins = Number(req.body.coins);
  if (!Number.isSafeInteger(id) || !Number.isSafeInteger(coins) || coins < 0 || coins > 1_000_000_000) {
    return res.status(400).json({ error: "Enter a whole-number balance from 0 to 1,000,000,000." });
  }
  const result = db.prepare("UPDATE users SET coins=? WHERE id=?").run(coins, id);
  if (!result.changes) return res.status(404).json({ error: "Account not found." });
  res.json({ user: publicUser(id) });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`SHUGE COINS running at http://localhost:${PORT}`));
